package org.vnelinpe.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.vnelinpe.entity.User;
import org.vnelinpe.service.UserService;

import java.util.UUID;

/**
 * TestController
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping("/save/{username}/{password}/{phone}")
    public User save(@PathVariable("username") String username,
                     @PathVariable("password") String password,
                     @PathVariable("phone") String phone) {
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setPhone(phone);
        userService.saveUser(user);
        return user;
    }

    @GetMapping("/update/{username}/{password}/{phone}")
    public User update(@PathVariable("username") String username,
                     @PathVariable("password") String password,
                     @PathVariable("phone") String phone) {
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setPhone(phone);
        userService.updateUser(user);
        return user;
    }
}

package org.vnelinpe.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.vnelinpe.annotation.OperationLog;
import org.vnelinpe.entity.User;
import org.vnelinpe.mapper.UserMapper;
import org.vnelinpe.service.UserService;

/**
 * UserServiceImpl
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;

    @Override
    @Transactional
    @OperationLog(entityClass = User.class, pkValues = "user.username")
    public void saveUser(User user) {
        userMapper.saveOne(user);
    }

    @Override
    @Transactional
    @OperationLog(entityClass = User.class, pkValues = "user.username")
    public void updateUser(User user) {
        userMapper.updateOne(user);
    }
}

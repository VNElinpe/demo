package org.vnelinpe.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.vnelinpe.entity.OperationLog;
import org.vnelinpe.mapper.OperationLogMapper;
import org.vnelinpe.service.OperationLogService;

/**
 * OperationLogServiceImpl
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
@Service
public class OperationLogServiceImpl implements OperationLogService {
    @Autowired
    private OperationLogMapper operationLogMapper;

    @Override
    @Transactional
    public void saveOne(OperationLog operationLog) {
        operationLogMapper.saveOne(operationLog);
    }
}

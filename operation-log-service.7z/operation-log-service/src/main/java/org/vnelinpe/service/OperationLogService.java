package org.vnelinpe.service;

import org.vnelinpe.entity.OperationLog;

/**
 * OperationLogService
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
public interface OperationLogService {
    /**
     * 保存日志
     * @param operationLog
     */
    void saveOne(OperationLog operationLog);
}

package org.vnelinpe.service;

import org.vnelinpe.entity.User;

/**
 * UserService
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
public interface UserService {
    /**
     * 保存用户信息
     * @param user
     */
    void saveUser(User user);

    /**
     * 更新用户信息
     * @param user
     */
    void updateUser(User user);
}

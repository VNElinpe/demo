package org.vnelinpe.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.vnelinpe.annotation.*;
import org.vnelinpe.mapper.OperationLogMapper;
import org.vnelinpe.service.OperationLogService;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

/**
 * OperationLogAOP
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
@Aspect
@Component
public class OperationLogAOP implements ApplicationContextAware {

    public static final String ENTITY_PK_DELIMITER = "\\.";
    private ApplicationContext applicationContext;

    @Autowired
    private OperationLogService operationLogService;

    @Pointcut("@annotation(org.vnelinpe.annotation.OperationLog) " +
            "|| @annotation(org.vnelinpe.annotation.OperationLogs)")
    private void pointcut(){}

    @Around("pointcut()")
    public Object log(ProceedingJoinPoint pjp) throws Throwable {
        Object[] args = pjp.getArgs();
        MethodSignature methodSignature = (MethodSignature) pjp.getSignature();
        String[] parameterNames = methodSignature.getParameterNames();
        Map<String, Object> parameterMap = new HashMap<>();
        for (int i = 0; i < parameterNames.length; i++) {
            parameterMap.put(parameterNames[i], args[i]);
        }
        // 获取主键值
        Object[] pkParamValues = null;
        Method method = methodSignature.getMethod();
        List<OperationLog> operationLogList = new ArrayList<>();
        if (method.isAnnotationPresent(OperationLog.class)) {
            operationLogList.add(method.getDeclaredAnnotation(OperationLog.class));
        }
        if (method.isAnnotationPresent(OperationLogs.class)) {
            operationLogList.addAll(Arrays.stream(method.getDeclaredAnnotation(OperationLogs.class).value()).toList());
        }

        // table的主键
        Map<String, String> tablePkNames = new HashMap<>();

        // 执行方法前
        Map<String, Object> before = getValueFromDB(operationLogList, parameterMap, tablePkNames, true);

        // 执行方法
        Object proceed = pjp.proceed();

        // 执行方法后
        Map<String, Object> after = getValueFromDB(operationLogList, parameterMap, tablePkNames, false);

        // 对比出有差异的字段
        Map<String, List<String>> diff = getDiff(before, after);

        if (!diff.isEmpty()) {
            diff.forEach((k,v) -> {
                org.vnelinpe.entity.OperationLog operationLog = new org.vnelinpe.entity.OperationLog();
                operationLog.setTableName(k);
                operationLog.setPrimaryKeys(tablePkNames.get(k));
                operationLog.setOperation(v.stream().collect(Collectors.joining(System.lineSeparator())));
                operationLogService.saveOne(operationLog);
            });
        }
        return proceed;
    }

    private Map<String, List<String>> getDiff(Map<String, Object> before, Map<String, Object> after) {
        Map<String, List<String>> result = new HashMap<>();
        if (Objects.equals(before, after)) {
            return result;
        }
        before.keySet().forEach(key -> {
            Object beforeObj = before.get(key);
            Object afterObj = after.get(key);
            // 对比出不一样的字段
            List<String> diffEntity = new ArrayList<>();
            if (beforeObj == null && afterObj != null) {
                Arrays.stream(afterObj.getClass().getDeclaredFields())
                        .filter(field -> field.isAnnotationPresent(LogTablePK.class)
                                || field.isAnnotationPresent(LogTableField.class))
                        .forEach(field -> {
                            StringBuilder sb = new StringBuilder();
                            sb.append("[");
                            if (field.isAnnotationPresent(LogTablePK.class)) {
                                sb.append(field.getAnnotation(LogTablePK.class).name());
                            }
                            else {
                                sb.append(field.getAnnotation(LogTableField.class).name());
                            }
                            sb.append("] : [null] --> [");
                            field.setAccessible(true);
                            try {
                                sb.append(field.get(afterObj)).append("]");
                            } catch (IllegalAccessException e) {
                                e.printStackTrace();
                                return;
                            }

                            diffEntity.add(sb.toString());
                        });
            }
            else if (beforeObj != null && afterObj == null) {
                Arrays.stream(beforeObj.getClass().getDeclaredFields())
                        .filter(field -> field.isAnnotationPresent(LogTablePK.class)
                                || field.isAnnotationPresent(LogTableField.class))
                        .forEach(field -> {
                            StringBuilder sb = new StringBuilder();
                            sb.append("[");
                            if (field.isAnnotationPresent(LogTablePK.class)) {
                                sb.append(field.getAnnotation(LogTablePK.class).name());
                            }
                            else {
                                sb.append(field.getAnnotation(LogTableField.class).name());
                            }
                            sb.append("] : [");
                            field.setAccessible(true);
                            try {
                                sb.append(field.get(beforeObj)).append("] --> [null]");
                            } catch (IllegalAccessException e) {
                                e.printStackTrace();
                                return;
                            }

                            diffEntity.add(sb.toString());
                        });
            }
            else {
                Arrays.stream(beforeObj.getClass().getDeclaredFields())
                        .filter(field -> field.isAnnotationPresent(LogTablePK.class)
                                || field.isAnnotationPresent(LogTableField.class))
                        .forEach(field -> {
                            StringBuilder sb = new StringBuilder();
                            sb.append("[");
                            if (field.isAnnotationPresent(LogTablePK.class)) {
                                sb.append(field.getAnnotation(LogTablePK.class).name());
                            }
                            else {
                                sb.append(field.getAnnotation(LogTableField.class).name());
                            }
                            sb.append("] : [");
                            field.setAccessible(true);
                            try {
                                sb.append(field.get(beforeObj)).append("] --> [");
                                sb.append(field.get(afterObj)).append("]");
                            } catch (IllegalAccessException e) {
                                e.printStackTrace();
                                return;
                            }
                            diffEntity.add(sb.toString());
                        });
            }
            result.put(key, diffEntity);
        });
        return result;
    }

    private Map<String, Object> getValueFromDB(List<OperationLog> operationLogList,
                                               Map<String, Object> parameterMap,
                                               Map<String, String> tablePkNames,
                                               boolean fillTablePkNames) {
        Map<String, Object> result = new HashMap<>();

        operationLogList.forEach(operationLog -> {
            // 获取pk参数值
            String[] pkValues = operationLog.pkValues();
            Object[] pkArgs = Arrays.stream(pkValues).map(pkValue -> {
                if (pkValue == null) {
                    return null;
                }
                String[] split = pkValue.split(ENTITY_PK_DELIMITER);
                if (split.length == 1) {
                    return split[0];
                }

                if (!parameterMap.containsKey(split[0])) {
                    return null;
                }

                Object value = parameterMap.get(split[0]);
                for (int i = 1; i < split.length; i++) {
                    try {
                        Field field = value.getClass().getDeclaredField(split[i]);
                        field.setAccessible(true);
                        value = field.get(value);
                    } catch (NoSuchFieldException | IllegalAccessException e) {
                        e.printStackTrace();
                        break;
                    }
                }
                return value;
            }).toArray();
            // 获取mapper方法
            Class entityClass = operationLog.entityClass();

            if (!entityClass.isAnnotationPresent(LogEntity.class)) {
                return;
            }

            LogEntity logEntity = (LogEntity) entityClass.getAnnotation(LogEntity.class);

            Class[] argsType = Arrays.stream(entityClass.getDeclaredFields())
                    .filter(field -> field.isAnnotationPresent(LogTablePK.class))
                    .sorted(Comparator.comparingInt(a -> a.getAnnotation(LogTablePK.class).order()))
                    .map(field -> field.getType()).toArray(Class[]::new);

            if (argsType.length != pkArgs.length) {
                return;
            }

            Object mapperBean = applicationContext.getBean(logEntity.mapperClass());
            if (mapperBean == null) {
                return;
            }

            if (fillTablePkNames) {
                String[] fieldNames = Arrays.stream(entityClass.getDeclaredFields())
                        .filter(field -> field.isAnnotationPresent(LogTablePK.class))
                        .sorted(Comparator.comparingInt(a -> a.getAnnotation(LogTablePK.class).order()))
                        .map(Field::getName).toArray(String[]::new);
                List<String> list = new ArrayList<>();
                for (int i = 0; i < fieldNames.length; i++) {
                    list.add(fieldNames[i] + "=" + pkArgs[i]);
                }
                tablePkNames.put(logEntity.tableName(), list.stream().collect(Collectors.joining(";")));
            }

            try {
                Method method = mapperBean.getClass().getDeclaredMethod(logEntity.findByPkMethodName(), argsType);
                Object invoke = method.invoke(mapperBean, pkArgs);
                result.put(logEntity.tableName(), invoke);
            } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                e.printStackTrace();
            }

        });

        return result;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}

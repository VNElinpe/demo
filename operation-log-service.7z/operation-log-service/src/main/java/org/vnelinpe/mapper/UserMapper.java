package org.vnelinpe.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.vnelinpe.entity.User;

/**
 * UserMapper
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
@Mapper
public interface UserMapper {
    /**
     * 根据username查询用户信息
     * @param username
     * @return
     */
    User findByUsername(String username);

    /**
     * 保存用户信息
     * @param user
     * @return
     */
    int saveOne(User user);

    /**
     * 更新用户信息
     * @param user
     * @return
     */
    int updateOne(User user);
}

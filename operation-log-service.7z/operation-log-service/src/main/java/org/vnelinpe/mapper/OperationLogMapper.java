package org.vnelinpe.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.vnelinpe.entity.OperationLog;

/**
 * OperationLogMapper
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
@Mapper
public interface OperationLogMapper {
    /**
     * 保存日志
     * @param operationLog
     * @return
     */
    int saveOne(OperationLog operationLog);
}

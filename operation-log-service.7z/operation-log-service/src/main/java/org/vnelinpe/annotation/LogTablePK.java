package org.vnelinpe.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * LogTablePK
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface LogTablePK {
    /**
     * 字段名
     * @return
     */
    String name();

    /**
     * 顺序
     * @return
     */
    int order() default 0;
}

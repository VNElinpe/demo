package org.vnelinpe.annotation;

import java.lang.annotation.*;

/**
 * OperationLog
 *
 * @author VNElinpe
 * @date 2022/7/14
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Repeatable(OperationLogs.class)
public @interface OperationLog {
    /**
     * entity
     * @return
     */
    Class entityClass();

    /**
     * 参数来源
     * @return
     */
    String[] pkValues();
}

package org.vnelinpe.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * LogEntity
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface LogEntity {
    /**
     * 表名
     * @return
     */
    String tableName();
    /**
     * mapper class
     * @return
     */
    Class mapperClass();

    /**
     * 根据主键查询的方法名
     * @return
     */
    String findByPkMethodName();
}

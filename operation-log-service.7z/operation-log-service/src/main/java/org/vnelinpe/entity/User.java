package org.vnelinpe.entity;

import lombok.Data;
import org.vnelinpe.annotation.LogEntity;
import org.vnelinpe.annotation.LogTableField;
import org.vnelinpe.annotation.LogTablePK;
import org.vnelinpe.mapper.UserMapper;

/**
 * User
 *
 * @author VNElinpe
 * @date 2022/7/14
 */
@Data
@LogEntity(tableName = "t_user", mapperClass = UserMapper.class, findByPkMethodName = "findByUsername")
public class User {
    private Long id;
    @LogTablePK(name = "用户名")
    private String username;
    @LogTableField(name = "密码")
    private String password;
    @LogTableField(name = "手机号码")
    private String phone;
}

package org.vnelinpe.entity;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * OperationLog
 *
 * @author VNElinpe
 * @date 2022/7/15
 */
@Data
public class OperationLog {
    private Long id;
    private String tableName;
    private String primaryKeys;
    private String operation;
    private String operationUser;
    private LocalDateTime createTime;
}
